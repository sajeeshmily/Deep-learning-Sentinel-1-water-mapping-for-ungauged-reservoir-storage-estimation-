# Deep Learning Sentinel-1 Water Mapping for Ungauged Reservoir Storage Estimation in Monsoon-Affected South India

Oct 21, 2026 · @sajeesh

## Abstract

**Background:** Reservoir storage data are essential for urban water supply planning, yet many reservoirs in South India lack accessible gauge records. Optical satellite monitoring is limited by cloud cover during the monsoon, when most inflow occurs, and simple radar thresholding is unreliable over dry reservoir beds.

**Objectives:** This study aimed to estimate and forecast reservoir storage without gauge data from the target reservoir, using Sentinel-1 radar and Sentinel-2 optical imagery.

**Methods:** U-Net models were trained on the public Sen1Floods11 dataset and applied to every available scene for four reservoirs supplying Chennai, India, over 2017–2020. Water area was converted to storage using rating curves fitted only on the other reservoirs. Storage forecasts at 7, 15 and 30 days were evaluated against gauge records.

**Results:** Radar thresholding mapped 67–72% of the maximum area as water over nearly empty reservoirs and showed almost no skill (NSE 0.06). The radar U-Net reduced this false water to 11–23% and estimated storage with an NSE of 0.80, providing about three observations per month during the northeast monsoon. Switching between optical and radar models by cloud cover raised 15-day forecast skill for 2019–2020 to an NSE of 0.83, and 0.80 in a fully gauge-free setting, compared with 0.58 using an optical water index. A fused radar–optical model did not transfer to the study area.

**Conclusion:** Learned radar segmentation makes year-round, gauge-free reservoir monitoring practical in monsoon regions, with forecast skill driven mainly by better storage estimates.

**Keywords:** reservoir storage; Sentinel-1; Sentinel-2; U-Net; ungauged reservoirs; monsoon; conformal prediction; Chennai

## 1. Introduction

Knowing how much water a reservoir holds is basic information for water supply planning, drought response and flood operations. In much of South India this information is hard to obtain. Many reservoirs and irrigation tanks have no gauge, and where gauges exist, records are often delayed, incomplete or not publicly released. Satellite remote sensing offers an alternative: the water surface area of a reservoir can be mapped from space and converted to storage through an area–storage relationship.

Optical satellites such as Sentinel-2 map open water well in clear conditions, but they cannot see through cloud. In Tamil Nadu, most reservoir inflow arrives during the northeast monsoon (October–December), exactly when cloud cover is heaviest. In this study, cloud-free Sentinel-2 views of the study reservoirs were available less than once a month during that season. An optical-only record therefore misses the periods when storage changes fastest.

Sentinel-1 synthetic aperture radar (SAR) images the surface regardless of cloud, with a 12-day repeat on a single orbit track. Its most common water-mapping methods, however, are simple backscatter thresholds. Smooth, dry surfaces can appear as dark as water in SAR images, and the exposed bed of a seasonally drawn-down reservoir is such a surface. A threshold that works on a full reservoir can therefore report large false water areas when the reservoir is nearly empty.

Deep learning segmentation models, particularly U-Net variants, have improved water mapping on image benchmarks. Their evaluation is almost always pixel-based (IoU, F1), and they are rarely tested on the hydrological quantity that matters: whether the mapped area tracks measured storage. It is also unclear whether models trained to tolerate missing optical data keep that robustness in regions they were not trained on.

This study addresses these questions on four reservoirs that supply Chennai, India: Poondi, Cholavaram, Red Hills (Puzhal) and Chembarambakkam. Its aim is to estimate and forecast reservoir storage without any gauge data from the target reservoir, using only public data and free computing resources. The specific objectives are to:

1. Train U-Net water segmentation models for Sentinel-1, Sentinel-2 and their fusion on a public benchmark, and test their robustness to cloud and to a held-out region.
2. Apply the models to every Sentinel-1 and Sentinel-2 scene of the study reservoirs for 2017–2020 and compare them with index and threshold methods against gauge storage.
3. Convert water area to storage with rating curves transferred from other reservoirs, and quantify how well this works without a gauge.
4. Forecast storage 7–30 days ahead from the satellite-derived record, with calibrated prediction intervals, and identify where the forecast error comes from.

The main contributions are: (i) evidence, measured against gauge storage, that a learned Sentinel-1 U-Net removes most of the dry-bed false water produced by thresholding and gives usable storage estimates through the monsoon; (ii) a sensor-switching strategy that combines optical and radar models by cloud cover, together with a documented negative result for robust SAR–optical fusion outside its training region; (iii) a fully gauge-free chain from imagery to 15-day storage forecasts; and (iv) an error budget showing that forecast skill depends mainly on the accuracy of the storage estimates rather than on the forecasting model.

## 2. Literature study

### 2.1 Deep learning for water body segmentation

The U-Net encoder–decoder architecture (Ronneberger et al., 2015) is the most common deep learning model for water body extraction from satellite images. Recent work adds attention, multi-scale or residual modules to it: a dual-attention, multi-scale U-Net for Sentinel-2 (Koyya et al., 2025), an EfficientNet–UNet with convolutional block attention (*Sensors*, 2026), a gated multi-filter U-Net using water indices and polarization information (MFGF-UNet) and a nested dense residual U-Net (NDR U-Net). Studies coupling water-body identification with water-level forecasting have used CNN and LSTM models with transfer learning (Kadam & Dhakne, 2025). These studies report IoU, F1 or pixel accuracy on image benchmarks. Whether the segmented area tracks measured reservoir storage is rarely tested.

### 2.2 Optical and radar monitoring of surface water

Global surface-water products are built from optical imagery, most notably the JRC Global Surface Water dataset derived from Landsat (Pekel et al., 2016). Spectral indices such as NDWI (McFeeters, 1996) and MNDWI (Xu, 2006) remain standard for mapping open water. Cloud cover is their main limitation in monsoon climates: in India's Western Ghats, mean cloud cover reached 90–92% in July–August, and the optical JRC product missed 23–25% of the surface water area that Sentinel-1 detected (Uday et al., 2025).

Sentinel-1 SAR avoids this, but backscatter thresholding, often with Otsu's method (Otsu, 1979), confuses water with other dark, smooth surfaces. Dry sand and bare ground produce many false alarms in arid regions (Martinis et al., 2018; Dasgupta et al., 2021; Garg et al., 2024), and thresholds need tuning to regional backscatter conditions (Uday et al., 2025). These studies concern flood mapping. The same failure over the exposed beds of seasonally emptying reservoirs, and its effect on storage estimates, has received little attention.

### 2.3 Estimating reservoir storage from space

Storage is usually derived from satellite water area through an area–elevation–storage relationship. For large reservoirs, satellite altimetry provides water levels that can be paired with area (Gao et al., 2012; Busker et al., 2019). For small or inaccessible reservoirs, digital elevation models (DEMs) have been used to reconstruct the topography of the reservoir basin, with cloud gaps filled by reconstruction (Avisse et al., 2017). Regional storage datasets now combine Landsat and Sentinel-2 water indices with DEM-derived or reconstructed bathymetry curves (Mahto et al., 2025). Machine learning has also been used to map satellite area to storage, trained on the reservoir's own gauge record (Retief et al., 2025).

These approaches need either altimetry, which covers mainly large water bodies, a DEM that predates the dam or reconstructed bathymetry, or local gauge data. Transferring area–storage relations from neighbouring gauged reservoirs, and doing so with radar-derived areas through the monsoon, is less explored.

### 2.4 SAR–optical fusion and robustness to cloud

The Sen1Floods11 dataset provides hand-labelled Sentinel-1 and Sentinel-2 water masks from flood events worldwide, with a held-out test region in Bolivia (Bonafilia et al., 2020). On this benchmark, Sentinel-2 indices outperformed Sentinel-1 bands, and adding elevation improved SAR-based segmentation (Konapala et al., 2021). Fusion of Sentinel-1 and Sentinel-2 improves water mapping where optical data are partly cloudy (Yin et al., 2024). Fusion models remain robust to cloud only when explicitly trained with cloud-like corruption (Mobsite et al., 2025). These evaluations use test data from the same regions as training, so it is not known whether this robustness transfers to new regions.

### 2.5 Reservoir water-level and storage forecasting

Machine learning models, especially LSTM networks and tree ensembles, are widely used to forecast reservoir and river water levels (Azad et al.). Most rely on gauge records as input. Where satellite data are used, the focus is usually on estimating current storage rather than forecasting it (Retief et al., 2025). Few studies separate how much forecast error comes from the observation frequency, from the area-to-storage conversion and from the forecasting model, or compare satellite-driven forecasts with simple persistence of the latest satellite estimate.

### 2.6 Research gaps

| # | Gap | How this study addresses it |
| --- | --- | --- |
| 1 | Segmentation is evaluated by pixel accuracy, not by agreement with storage | Every method is scored against gauge storage |
| 2 | Optical monitoring fails during the monsoon; gauge-free methods depend on optical data, DEMs or altimetry | Sentinel-1 U-Net with rating curves transferred from other reservoirs |
| 3 | Radar thresholding produces false water over dry, smooth surfaces | False water on near-empty reservoir beds is measured for thresholding and the U-Net |
| 4 | Ungauged methods rarely transfer area–storage relations between reservoirs | Leave-one-reservoir-out rating curves |
| 5 | Robustness of SAR–optical fusion is tested only in-distribution | Fusion tested on a held-out region and on the study reservoirs |
| 6 | Satellite-driven forecasts are not decomposed or compared with persistence | Error budget and persistence benchmark |

## 3. Study area and data

### 3.1 Study area

The study covers the four rain-fed reservoirs that supply Chennai, Tamil Nadu (Table 1). They lie within about 40 km of each other on the coastal plain and are linked by canals, and Poondi also receives transfers under the Krishna water supply scheme. Rainfall is concentrated in the northeast monsoon (October–December), with a smaller contribution from the southwest monsoon (June–September). Storage swings from near-empty to full within months: all four reservoirs were almost dry in mid-2019 and close to full after the 2015 and late-2020 monsoons (Figure 1).

**Table 1.** Study reservoirs. Capacity is the full-reservoir storage used to normalise the gauge record; the mask is the JRC maximum water extent plus a 300 m buffer.

| Reservoir | Capacity (mcft) | Capacity (MCM) | Mask area (km²) | Gauge record |
| --- | --- | --- | --- | --- |
| Poondi | 3231 | 91.5 | 46.0 | Reliable |
| Cholavaram | 881 | 24.9 | 11.1 | Flagged (see 3.3) |
| Red Hills (Puzhal) | 3300 | 93.4 | 29.0 | Reliable |
| Chembarambakkam | 3645 | 103.2 | 31.8 | Reliable |

![Figure 1. Daily gauge storage (line, % of capacity) and rainfall (bars) for the four reservoirs, 2004–2020. Dashed lines mark the training, calibration and test periods.](figures/Fig1_data_overview.png)

**Figure 1.** Daily gauge storage (% of capacity) and rainfall for the four reservoirs, 2004–2020. Dashed lines separate the training (2004–2014), calibration (2015–2016) and test (2017–2020) periods.

### 3.2 Data

**Table 2.** Data used in this study. All data are public.

| Data | Source | Period | Use |
| --- | --- | --- | --- |
| Sen1Floods11 hand-labelled chips (Sentinel-1 VV/VH, Sentinel-2 13 bands, water masks) | Bonafilia et al. (2020) | Global flood events | Training and testing segmentation models |
| Sentinel-1 GRD, IW mode, VV and VH | Copernicus, via Google Earth Engine (Gorelick et al., 2017) | 2017–2020 | Reservoir water mapping |
| Sentinel-2 L1C top-of-atmosphere reflectance | Copernicus, via Google Earth Engine | 2017–2020 | Reservoir water mapping |
| Sentinel-2 cloud probability (s2cloudless) | Copernicus, via Google Earth Engine | 2017–2020 | Cloud masking |
| JRC Global Surface Water, maximum extent | Pekel et al. (2016) | 1984–2021 | Reservoir masks |
| Daily reservoir storage (mcft) and rainfall (mm) | Chennai Water Management dataset, Kaggle | 2004-01-01 to 2020-12-03 | Validation, rating curves, forecasting |
| CHIRPS daily rainfall | Funk et al. (2015) | 2017–2020 | Gauge-free forecasting |
| ERA5-Land daily evaporation and temperature | Muñoz-Sabater et al. (2021) | 2017–2020 | Exported; not used in the reported models |

### 3.3 Gauge data quality

The gauge record contained 30 values in 11 isolated blocks of one to three days that jumped by more than 15% of capacity and returned; several occurred on the same dates at all four reservoirs (for example 6 January 2005, 10–12 June 2005 and 17 January 2015), indicating recording errors. These values were replaced by linear interpolation. The Cholavaram record stays almost flat for months at a time (for example through 2020) while both Sentinel-1 and Sentinel-2 show its water spread changing. Its gauge was therefore not used to fit any rating curve or pooled statistic, and its results are reported separately. Pooled results use Poondi, Red Hills and Chembarambakkam.

Monthly CHIRPS rainfall correlated with the gauge rainfall at each reservoir with r = 0.78–0.86 over 2017–2020, supporting its use as a gauge-free rainfall input.

## 4. Methods

The method has five steps (Figure 2): train water segmentation models on a public benchmark; map water area for every satellite scene of the reservoirs; convert area to storage; forecast storage; and evaluate everything against gauge storage. A detailed flow chart is given in Figure S1. All processing used free resources: Google Earth Engine, Kaggle (NVIDIA T4 GPU) and Google Colab.

![Figure 2. Overview of the method.](figures/Fig2_block_diagram.png)

**Figure 2.** Overview of the method. Sentinel-1 and Sentinel-2 imagery is segmented with U-Net models trained on Sen1Floods11, switching between optical and radar models by cloud cover. Water area is converted to storage with rating curves from other gauged reservoirs and used to forecast storage 7–30 days ahead; all outputs are evaluated against gauge records.

### 4.1 Water segmentation models

Three U-Net models (Ronneberger et al., 2015) with a ResNet-18 encoder (He et al., 2016) pre-trained on ImageNet were implemented with the segmentation\_models\_pytorch library (Iakubovskii, 2019; 14.3 million parameters each). They differ only in their input:

- **S2 U-Net:** six Sentinel-2 bands (B2, B3, B4, B8, B11, B12), as reflectance.
- **S1 U-Net:** Sentinel-1 VV and VH backscatter (dB), clipped to −50 to 5 dB.
- **Fused U-Net:** all eight channels.

Each channel was standardised with the mean and standard deviation of the training split. A spatial dropout layer (p = 0.2) before the output layer allowed Monte Carlo (MC) dropout uncertainty estimation (Gal & Ghahramani, 2016).

The fused model was trained in two versions. The robust version applied, to each training sample: removal of all optical channels (probability 0.25), synthetic cloud masks covering 10–90% of the optical channels (0.30), or removal of the SAR channels (0.05). Removed values were set to zero, which equals the training mean after standardisation. The other version used no such corruption.

Models were trained on the Sen1Floods11 hand-labelled training split with random 256 × 256 crops (four per chip per epoch), random flips and 90° rotations. The loss was binary cross-entropy plus Dice loss, ignoring unlabelled pixels. Training used AdamW (learning rate 10⁻³, weight decay 10⁻⁴), a one-cycle schedule, batch size 16, mixed precision and 40 epochs. The checkpoint with the best validation IoU was kept. Each configuration was trained with two random seeds; one run took 6–7 minutes on a T4 GPU.

Four training-free baselines were evaluated on the same data: NDWI > 0 (McFeeters, 1996), MNDWI > 0 (Xu, 2006), a fixed VV threshold of −16 dB, and an Otsu threshold on VV (Otsu, 1979) constrained to −22 to −12 dB.

Segmentation was scored on the test split and on the held-out Bolivia split with IoU, F1, precision and recall, pooled over all labelled pixels. Robustness to cloud was tested by masking 0–100% of the optical channels with synthetic clouds at test time. Uncertainty was assessed with 20 MC-dropout passes, using the expected calibration error (ECE) and the AUROC with which per-pixel uncertainty identifies misclassified pixels.

### 4.2 Reservoir water mapping

Each reservoir mask was the connected component of the JRC maximum water extent (Pekel et al., 2016) at the reservoir, buffered by 300 m. Scenes were selected from metadata only: Sentinel-2 tiles that fully contain the reservoir and have less than 70% tile-wide cloud, keeping the least cloudy tile per date; and Sentinel-1 scenes on the dominant orbit track (relative orbit 92, descending), mosaicked per day. This gave 162–178 Sentinel-2 scenes and 124 Sentinel-1 dates per reservoir for 2017–2020.

Instead of exporting images, each scene was fetched directly into memory from Earth Engine on a fixed 10 m UTM (EPSG:32644) grid, processed, and discarded. Six methods were applied to identical pixels: the three U-Nets, MNDWI, NDWI and Otsu thresholding of VV. For the fused model, a Sentinel-2 scene was paired with a Sentinel-1 scene acquired within three days; Sentinel-1 dates without a partner were run with the optical channels removed. Water area was the number of water pixels inside the mask, averaged over 10 MC-dropout passes.

Pixels with s2cloudless probability above 50% were treated as cloud. Optical methods counted only cloud-free pixels, and their estimates were kept only for scenes with less than 10% cloud over the reservoir. A sensor-switching series was then formed: the S2 U-Net on clear dates and the S1 U-Net on all other dates.

### 4.3 Area-to-storage conversion

Storage S was related to water area A with a power-law rating curve:

```latex
S = a + b\,A^{c}, \qquad 0.3 \le c \le 4
```

Two versions were fitted for each method. The **gauged** curve used the reservoir's own gauge record, scored by five-fold, time-blocked cross-validation. The **ungauged** curve used no gauge data from the target reservoir. It was fitted on the other reservoirs (excluding Cholavaram) in dimensionless form:

```latex
\frac{S}{S_{\mathrm{cap}}} = a + b\left(\frac{A}{A_{\max}}\right)^{c}
```

where S\_cap is the reservoir capacity and A\_max is the largest area the same method recorded at that reservoir, so that no gauge data are needed to apply it. Satellite storage was matched to the gauge reading on the same day.

False water over dry beds was measured as the median mapped area on dates when gauge storage was below 5% of capacity, expressed as a percentage of the 98th-percentile area of the same method.

### 4.4 Storage forecasting

Forecasts were made for lead times h = 7, 15 and 30 days. The target was the change in storage, as a fraction of capacity, from the forecast date to h days later. Inputs were storage at lags of 0, 1, 3, 7, 14, 30 and 60 days; 7- and 30-day changes; rainfall sums over 1–90 days at the reservoir and averaged across all four; day-of-year terms; and remaining capacity.

Six models were compared: persistence (no change), day-of-year climatology of the change, ridge regression on lagged inputs (AR-ridge), random forest, histogram gradient boosting (HistGB) and a multilayer perceptron. The record was split chronologically into training (2004–2014), calibration (2015–2016) and test (2017–2020) periods. Transfer to unseen reservoirs was tested by training HistGB on three reservoirs and testing on the fourth.

**Prediction intervals.** 90% intervals were built with split conformal prediction (Vovk et al., 2005) on the calibration period; with Mondrian conformal prediction, calibrated separately for each reservoir and season (dry: January–May; southwest monsoon: June–September; northeast monsoon: October–December); and with adaptive conformal inference (Gibbs & Candès, 2021), updated only with errors known h days later. Quantile-regression HistGB served as a non-conformal baseline. Intervals were clipped to 0–105% of capacity.

**Satellite-driven forecasts.** To forecast from satellite storage, HistGB was trained on the 2004–2014 gauge record with its inputs degraded to mimic satellite observation: a 10-day revisit, 60% of June–December observations lost to cloud, Gaussian noise of 8% of capacity, and, for inputs that include Sentinel-1, a 12-day cloud-independent observation. The number of days since the last observation was added as an input. At test time, the satellite-derived storage (ungauged rating curve) was carried forward between observations. In the fully gauge-free version, the model was trained without the target reservoir and gauge rainfall was replaced by CHIRPS. Forecasts were scored against gauge storage over 2017–2020 and over 2019–2020, the period also used in an earlier optical-only test (Section 5.4).

### 4.5 Evaluation metrics

Agreement with gauge storage was measured with the Nash–Sutcliffe efficiency (NSE; Nash & Sutcliffe, 1970), the Kling–Gupta efficiency (KGE; Gupta et al., 2009), RMSE, MAE and percent bias, computed on storage as a fraction of capacity when pooled across reservoirs:

```latex
\mathrm{NSE} = 1 - \frac{\sum_t (O_t - P_t)^2}{\sum_t (O_t - \bar{O})^2}
```

Forecast gains over persistence were tested with the Diebold–Mariano test (Diebold & Mariano, 1995) with the small-sample correction of Harvey et al. (1997). Intervals were scored by coverage (PICP), mean width (MPIW) and the Winkler score. Results are reported for all test days and by season.

## 5. Results

### 5.1 Segmentation benchmark (Sen1Floods11)

The learned SAR model doubled the accuracy of SAR thresholding, while optical models remained the most accurate overall (Table 3). On the test split, the S1 U-Net reached an IoU of 0.670, against 0.316 for Otsu thresholding and 0.467 for a fixed −16 dB threshold. The S2 U-Net (0.836) and both fused models (0.834–0.845) performed similarly, and all U-Nets outperformed NDWI (0.758) and MNDWI (0.650).

On the held-out Bolivia region, the ranking changed. NDWI (0.832) outperformed every learned model, the S2 U-Net (0.795) outperformed both fused models, and the robust fused model (0.653) was no better than the S1 U-Net (0.650).

**Table 3.** Segmentation accuracy (IoU, mean ± standard deviation over two seeds) and calibration. "No optical" = optical channels removed at test time. ECE and uncertainty AUROC are for the test split.

| Method | IoU, test | IoU, Bolivia | IoU, test, no optical | IoU, Bolivia, no optical | ECE | Uncertainty AUROC |
| --- | --- | --- | --- | --- | --- | --- |
| NDWI > 0 | 0.758 | 0.832 | – | – | – | – |
| MNDWI > 0 | 0.650 | 0.551 | – | – | – | – |
| S1 VV < −16 dB | 0.467 | 0.472 | – | – | – | – |
| S1 VV Otsu | 0.316 | 0.456 | – | – | – | – |
| S2 U-Net | 0.836 ± 0.003 | 0.795 ± 0.017 | – | – | 0.021 | 0.936 |
| S1 U-Net | 0.670 ± 0.010 | 0.650 ± 0.012 | – | – | 0.046 | 0.864 |
| Fused U-Net | 0.845 ± 0.004 | 0.732 ± 0.011 | 0.000 | 0.002 | 0.016 | 0.934 |
| Fused U-Net, robust | 0.834 ± 0.005 | 0.653 ± 0.028 | 0.639 ± 0.016 | 0.458 ± 0.046 | 0.020 | 0.924 |

Robustness training worked in-distribution but did not transfer (Figure 3). On the test split, the robust fused model lost only 0.20 IoU as cloud cover rose from 0% to 100%, and stayed above the S1 U-Net up to about 90% cloud. Without robustness training, the fused model behaved like the S2 U-Net and fell to zero. On Bolivia, the S2 U-Net was best below about 20% cloud and the S1 U-Net was best above it, so the robust fused model was never the best choice.

All U-Nets were well calibrated (ECE 0.016–0.046), and MC-dropout uncertainty identified misclassified pixels with an AUROC of 0.86–0.94 on the test split and 0.82–0.90 on Bolivia.

![Figure 3. IoU against the fraction of optical pixels obscured by synthetic cloud.](figures/Fig3_cloud_robustness.png)

**Figure 3.** IoU against the fraction of optical pixels obscured by synthetic cloud, on the Sen1Floods11 test split (left) and the held-out Bolivia region (right). Shading spans the two seeds; the dashed line is the cloud-independent S1 U-Net.

### 5.2 Reservoir water mapping and storage estimation

On the study reservoirs, the S1 U-Net turned Sentinel-1 from unusable into a reliable storage estimator (Table 4, Figure 4). Pooled over the three reliable reservoirs and using ungauged rating curves, it reached an NSE of 0.798, against 0.064 for Otsu thresholding. Rank correlation between mapped area and gauge storage rose from 0.00–0.65 with Otsu to 0.88–0.95 with the S1 U-Net.

On clear scenes, optical methods were the most accurate. MNDWI achieved the best ungauged NSE (0.826), ahead of the S2 U-Net (0.764), and with own-reservoir gauged curves both reached NSE 0.97–0.98 at Poondi and Red Hills. Clear scenes were scarce, however: only 65–79 of 162–178 Sentinel-2 scenes per reservoir had less than 10% cloud over the reservoir.

**Table 4.** Storage estimated from satellite water area with ungauged rating curves (fitted on other reservoirs): NSE per reservoir and pooled over the three reliable reservoirs, with pooled RMSE (% of capacity). Cholavaram's gauge is flagged as unreliable.

| Method | Poondi | Red Hills | Chembarambakkam | Pooled NSE | Pooled RMSE (%) | Cholavaram |
| --- | --- | --- | --- | --- | --- | --- |
| MNDWI > 0 | 0.895 | 0.821 | 0.715 | 0.826 | 10.8 | 0.004 |
| NDWI > 0 | 0.861 | 0.853 | 0.474 | 0.775 | 12.3 | −0.372 |
| S2 U-Net | 0.881 | 0.822 | 0.467 | 0.764 | 12.6 | 0.047 |
| S1 Otsu | −0.476 | 0.129 | 0.119 | 0.064 | 24.2 | −0.937 |
| S1 U-Net | 0.748 | 0.909 | 0.587 | 0.798 | 11.3 | −0.919 |
| Fused U-Net, robust | 0.623 | 0.308 | 0.226 | 0.402 | 19.3 | −0.356 |
| Switching (S2 U-Net clear, S1 U-Net otherwise) | 0.812 | 0.871 | 0.529 | 0.779 | 11.8 | −0.431 |

![Figure 4. Water area against gauge storage for SAR and optical methods.](figures/Fig4_area_vs_storage.png)

**Figure 4.** Water area against gauge storage (% of capacity). Top: Sentinel-1 Otsu thresholding and S1 U-Net. Bottom: MNDWI and S2 U-Net on clear scenes. ρ = Spearman rank correlation.

**False water on dry beds.** When gauge storage was below 5% of capacity, Otsu thresholding still mapped 67–72% of the reservoir's maximum area as water at Poondi, Red Hills and Cholavaram, and 53% at Chembarambakkam (Table 5). The S1 U-Net reduced this to 11–23% at Poondi, Red Hills and Cholavaram, close to the optical methods. At Chembarambakkam, every method, including the optical ones, mapped 29–46% of the maximum area as water when the gauge read near zero.

**Table 5.** Median mapped area when gauge storage was below 5% of capacity, as % of each method's 98th-percentile area.

| Method | Poondi | Red Hills | Cholavaram | Chembarambakkam |
| --- | --- | --- | --- | --- |
| S1 Otsu | 66.7 | 70.1 | 71.8 | 52.6 |
| S1 U-Net | 11.0 | 22.6 | 14.2 | 45.7 |
| S2 U-Net | 6.3 | 11.8 | 6.1 | 32.5 |
| MNDWI > 0 | 6.7 | 17.0 | 9.5 | 29.0 |

**Monsoon coverage.** Sentinel-2 provided 0.9 usable observations per reservoir per month during the northeast monsoon, against 3.0 for Sentinel-1; switching provided 3.6. The S1 U-Net was the most accurate method in the southwest monsoon (NSE 0.884) and kept an NSE of 0.732 in the northeast monsoon. Figure 5 shows the resulting storage series: Otsu-derived storage stayed near 25–50% of capacity regardless of the true storage, while the S1 U-Net followed the gauge through both fills and drawdowns.

![Figure 5. Satellite-derived storage from ungauged rating curves compared with gauge storage, 2017–2020.](figures/Fig5_storage_timeseries.png)

**Figure 5.** Satellite-derived storage (ungauged rating curves) for S1 Otsu, S1 U-Net and S2 U-Net, compared with gauge storage, 2017–2020.

**Failure of the fused model.** Applied to the reservoirs, the robust fused model reached only NSE 0.402. In 34 of 191 scenes without optical data (18%), its water area fell below 40% of the S1 U-Net's, sometimes to almost zero while the reservoir was over 70% full; this happened in only 6 of 122 clear scenes. This matches its weak no-optical performance on Bolivia.

### 5.3 Forecasting from gauge data

With daily gauge storage as input, all models were highly skilful, but so was persistence (Table 6). Pooled over the four reservoirs on the 2017–2020 test period, AR-ridge and random forest gave the best NSE (0.985 at 7 days, 0.947–0.948 at 15 days, 0.835–0.864 at 30 days), against 0.976, 0.927 and 0.808 for persistence. The Diebold–Mariano test found no statistically significant gain of HistGB over persistence at any reservoir or lead time (p = 0.10–0.92).

**Table 6.** Gauge-driven forecast skill, pooled over four reservoirs, 2017–2020 (NSE; RMSE in % of capacity).

| Model | NSE 7 d | NSE 15 d | NSE 30 d | RMSE 7 d | RMSE 15 d | RMSE 30 d |
| --- | --- | --- | --- | --- | --- | --- |
| Persistence | 0.976 | 0.927 | 0.808 | 3.67 | 6.47 | 10.49 |
| Climatology | 0.979 | 0.939 | 0.857 | 3.42 | 5.88 | 9.06 |
| AR-ridge | 0.985 | 0.948 | 0.864 | 2.96 | 5.47 | 8.85 |
| Random forest | 0.985 | 0.947 | 0.835 | 2.93 | 5.52 | 9.75 |
| HistGB | 0.983 | 0.938 | 0.825 | 3.12 | 5.93 | 10.03 |
| MLP | 0.977 | 0.907 | 0.706 | 3.59 | 7.27 | 13.01 |

Gains were concentrated in the dry season, when random forest cut the 7-day RMSE from 2.4% to 1.5% of capacity. In the northeast monsoon at 30 days, random forest and HistGB were no better than persistence (NSE 0.46–0.48); only AR-ridge improved on it (0.66).

Models transferred well to reservoirs they had not seen. A HistGB model trained on the other three reservoirs matched or exceeded one trained on the target's own data in most cases (for example at Chembarambakkam, 30 days: NSE 0.787 against 0.613). It did not always beat persistence: at Chembarambakkam and Cholavaram at 30 days, persistence remained better.

### 5.4 Forecasting from satellite-derived storage

Using the sensor-switching record as input raised satellite-driven forecast skill substantially (Table 7, Figure 6). For 2019–2020, 15-day forecasts reached NSE 0.827, and 0.800 in the fully gauge-free setting. An earlier optical-only test over the same period, using MNDWI with the Sentinel-2 L2A scene classification cloud mask, achieved 0.642 and 0.583 respectively. Inputs from Otsu thresholding or the robust fused model gave little or no skill (NSE 0.09–0.39).

**Table 7.** Satellite-driven forecast skill (NSE), pooled over Poondi, Red Hills and Chembarambakkam. Gauge-free = forecaster trained on other reservoirs, CHIRPS rainfall, ungauged rating curves.

| Input | 7 d, 2019–20 | 15 d, 2019–20 | 30 d, 2019–20 | 15 d, 2017–20 |
| --- | --- | --- | --- | --- |
| Daily gauge storage (reference) | 0.990 | 0.963 | 0.882 | 0.949 |
| Switching | 0.854 | 0.827 | 0.740 | 0.719 |
| Persistence of switching | 0.853 | 0.826 | 0.739 | 0.710 |
| Gauge-free, switching | 0.845 | 0.800 | 0.707 | 0.697 |
| S1 U-Net | 0.835 | 0.799 | 0.712 | 0.716 |
| MNDWI > 0 | 0.766 | 0.723 | 0.656 | 0.611 |
| S2 U-Net | 0.748 | 0.711 | 0.641 | 0.544 |
| Fused U-Net, robust | 0.382 | 0.388 | 0.359 | 0.389 |
| S1 Otsu | 0.093 | 0.093 | 0.105 | 0.052 |

The forecasting model added almost nothing beyond the satellite estimate itself: persistence of the switching record scored within 0.01 NSE of the trained model at every lead time. An error budget from the earlier optical-only test shows where the skill was lost. At 15 days, daily gauge input gave NSE 0.963; real Sentinel-2 observation dates with exact storage values gave 0.867; and real Sentinel-2-derived storage gave 0.642. Sparse sampling therefore cost about 0.10 NSE, and the area-to-storage step about 0.22.

![Figure 6. 15-day-ahead storage forecasts driven by satellite-derived storage.](figures/Fig6_satellite_forecasts.png)

**Figure 6.** 15-day-ahead storage forecasts driven by MNDWI-derived and switching-derived storage, compared with gauge storage, 2017–2020.

### 5.5 Prediction intervals

Season-aware conformal intervals held their coverage during the northeast monsoon, where the standard method failed (Table 8, Figure 7). Split conformal intervals reached 92–94% coverage overall but only 72–80% during the northeast monsoon. Mondrian conformal intervals, calibrated by season and reservoir, reached 93–95% overall and 94% in the northeast monsoon at 7 and 15 days, with intervals about 10% wider. At 30 days, they over-covered in that season (100%), because the calibration years include the extreme 2015 floods. Adaptive conformal inference kept 90% overall but fell to 66–68% in the monsoon, and quantile regression under-covered throughout (67–78%).

**Table 8.** 90% prediction intervals for HistGB forecasts, pooled over four reservoirs, 2017–2020. Coverage = share of observations inside the interval; width in % of capacity.

| Method | Coverage 7 d | NE monsoon 7 d | Width 7 d | Coverage 15 d | NE monsoon 15 d | Width 15 d | Coverage 30 d | NE monsoon 30 d |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Quantile regression | 0.776 | 0.786 | 4.0 | 0.702 | 0.738 | 7.9 | 0.665 | 0.682 |
| Split conformal | 0.919 | 0.720 | 8.4 | 0.918 | 0.718 | 17.4 | 0.944 | 0.802 |
| Mondrian conformal | 0.947 | 0.941 | 9.3 | 0.928 | 0.942 | 17.5 | 0.934 | 1.000 |
| Adaptive conformal | 0.896 | 0.658 | 7.4 | 0.897 | 0.662 | 19.8 | 0.898 | 0.684 |

![Figure 7. Coverage of 90% prediction intervals on all test days and during the northeast monsoon.](figures/Fig7_interval_coverage.png)

**Figure 7.** Coverage of 90% prediction intervals on all test days and during the northeast monsoon, for 7-, 15- and 30-day lead times (HistGB forecasts). The dashed line marks the 90% target.

## 6. Discussion

### 6.1 Why the learned SAR model matters

The central result is that a U-Net trained on public flood data turns Sentinel-1 into a usable storage estimator for seasonal reservoirs. Thresholding failed for a specific, physical reason: exposed reservoir beds are smooth and dry, so they scatter radar away from the sensor like open water does. This is the same confusion reported for desert sand in arid flood mapping (Martinis et al., 2018; Garg et al., 2024), now shown on drawn-down reservoir beds and measured against storage. A single global threshold cannot separate the two, but a convolutional model can use texture, shape and context, including the VH channel, and it reduced dry-bed false water from 67–72% to 11–23% of maximum area at three of the four reservoirs.

This matters most in the monsoon. Optical methods were the most accurate on clear days, as on the benchmark (Konapala et al., 2021), but they provided less than one observation per reservoir per month during the northeast monsoon, consistent with the cloud losses reported elsewhere in India (Uday et al., 2025). The S1 U-Net provided three, with an NSE of 0.73–0.88 across the two monsoon seasons. Satellite water monitoring in monsoon regions is therefore best treated as a radar problem with optical support, not the other way round.

### 6.2 Fusion versus sensor switching

The robust fused model looked best on the in-distribution benchmark, degrading gracefully as cloud increased, in line with reports that cloud-aware training makes fusion robust (Mobsite et al., 2025). Outside its training regions, the same model was the weakest U-Net: on Bolivia and on the study reservoirs it frequently collapsed when the optical channels were missing. A plausible explanation is that the model learned to rely on optical patterns specific to the training regions, so that zeroed optical inputs in a new region push it outside anything it has seen. Switching between two single-sensor models avoids this dependency and was more reliable in both out-of-distribution tests. For operational use in a new region, we recommend evaluating fusion models on held-out regions before adopting them, and preferring sensor switching otherwise.

### 6.3 Where forecast skill comes from

Two results limit what can be claimed for the forecasting models. With daily gauge input, machine learning gains over persistence were small and not statistically significant, apart from the dry season, because storage in these reservoirs changes slowly except during inflow events, which the models cannot anticipate from past rainfall alone. With satellite input, the trained model performed no better than carrying forward the latest satellite estimate.

The error budget explains the second result: most of the gap between satellite-driven and gauge-driven forecasts comes from errors in the storage estimates (about 0.22 NSE at 15 days), not from sparse observation dates (about 0.10). Improving water mapping and rating curves therefore helps forecasting more than better forecasting models or denser revisit. The step from optical-only (NSE 0.58) to radar-based gauge-free forecasts (0.80) supports this: the forecasting set-up was essentially unchanged (the same model and training period, with radar revisit added to the simulated inputs), while the storage estimates improved.

### 6.4 Uncertainty that reflects the season

Forecast errors are much larger during the northeast monsoon than in the dry season. Conformal intervals calibrated over all seasons are too wide in the dry season and too narrow in the monsoon, which is exactly when a water manager needs them. Calibrating by season and reservoir fixed this at 7 and 15 days with little extra width. Adaptive conformal inference, often recommended for changing conditions (Gibbs & Candès, 2021), reacted too slowly here because each forecast's error is known only h days later, by which time the monsoon event has passed.

### 6.5 Limitations

- **Small sample.** Four reservoirs, three with reliable gauges, in one region. Leave-one-reservoir-out results rest on rating curves fitted on two reservoirs, and should be confirmed on a larger set.
- **Gauge quality.** The Cholavaram record appears unreliable, and at Chembarambakkam all methods mapped substantial water when the gauge read near zero. This may be water below the gauge's zero level (dead storage) or vegetation on the bed; we could not verify which.
- **Two training seeds.** Segmentation results are averaged over two seeds; differences below about 0.02 IoU should not be over-interpreted.
- **Operated reservoirs.** Releases and inter-reservoir transfers, including Krishna water inflows to Poondi, are not in the public data, which limits forecast skill at longer leads.
- **No rainfall forecasts.** Forecasts used only past rainfall; numerical weather forecasts could improve skill during inflow events.
- **Rating-curve form.** A single power law per method was assumed; reservoirs with complex shapes may need other forms or DEM-based curves (Avisse et al., 2017).
- **Benchmark domain.** Sen1Floods11 contains flood scenes, not reservoirs; fine-tuning on a small set of labelled reservoir scenes could reduce the remaining dry-bed errors.

## 7. Conclusions

This study tested whether reservoir storage can be monitored and forecast through the monsoon without gauge data from the target reservoir, using Sentinel-1 and Sentinel-2 imagery and U-Net segmentation, on four reservoirs supplying Chennai over 2017–2020. The main findings are:

1. A Sentinel-1 U-Net trained on public flood data estimated storage with an NSE of 0.80 using rating curves transferred from other reservoirs, against 0.06 for Otsu thresholding. It reduced false water over near-empty reservoir beds from 67–72% to 11–23% of maximum area at three of the four reservoirs.
2. Sentinel-1 provided about three observations per reservoir per month in the northeast monsoon, against fewer than one cloud-free Sentinel-2 view, making radar the backbone of year-round monitoring. Optical indices remained the most accurate on clear days.
3. A fused SAR–optical model trained to tolerate missing optical data performed well in-distribution but failed on a held-out region and on the study reservoirs. Switching between single-sensor models by cloud cover was more reliable.
4. Fully gauge-free 15-day forecasts for 2019–2020 reached an NSE of 0.80, against 0.58 with optical-only inputs. The gain came from better storage estimates; the forecasting model performed at the level of persistence of the satellite estimate.
5. Season-aware (Mondrian) conformal intervals held about 94% coverage in the northeast monsoon at 7–15-day leads, where standard intervals covered only 72%.

Future work should test the approach on more reservoirs and regions, fine-tune the radar model on labelled reservoir scenes, add rainfall forecasts and reservoir operations, and verify dead-storage levels before interpreting low-storage estimates.

### Data and code availability

All input data are public: Sen1Floods11, Sentinel-1 and Sentinel-2 via Google Earth Engine, JRC Global Surface Water, CHIRPS, ERA5-Land and the Chennai Water Management dataset on Kaggle. The code for segmentation training, image streaming, rating curves, forecasting and evaluation will be made available at \[repository link to be added\].

### Supplementary material

![Figure S1. Detailed methodology flow chart.](figures/FigS1_methodology_flowchart.png)

**Figure S1.** Detailed methodology flow chart: data, segmentation models and gauge preparation, reservoir water mapping, storage estimation and forecasting, and evaluation.

## References

Entries marked \[verify\] have details (authors, year, journal or DOI) that were not confirmed from the publisher's page and must be checked before submission.

- Avisse, N., Tilmant, A., Müller, M. F., & Zhang, H. (2017). Monitoring small reservoirs' storage with satellite remote sensing in inaccessible areas. *Hydrology and Earth System Sciences, 21*, 6445–6459. <https://doi.org/10.5194/hess-21-6445-2017>
- Azad, A. S., Islam, N., Nabi, M. N., Khurshid, H., & Siddique, M. A. Developments and trends in water level forecasting using machine learning models—A review. \[verify year, journal, DOI\] ([record](https://pure.kfupm.edu.sa/en/publications/developments-and-trends-in-water-level-forecasting-using-machine-/))
- Bonafilia, D., Tellman, B., Anderson, T., & Issenberg, E. (2020). Sen1Floods11: A georeferenced dataset to train and test deep learning flood algorithms for Sentinel-1. *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition Workshops*. \[verify authors\] ([paper](https://openaccess.thecvf.com/content_CVPRW_2020/html/w11/Bonafilia_Sen1Floods11_A_Georeferenced_Dataset_to_Train_and_Test_Deep_Learning_CVPRW_2020_paper.html))
- Busker, T., de Roo, A., Gelati, E., Schwatke, C., Adamovic, M., Bisselink, B., Pekel, J.-F., & Cottam, A. (2019). A global lake and reservoir volume analysis using a surface water dataset and satellite altimetry. *Hydrology and Earth System Sciences, 23*, 669–690. <https://doi.org/10.5194/hess-23-669-2019>
- Dasgupta, A., Goodman, M., Yague Martinez, N., & Tellman, B. (2021). Improving operational SAR-based flood mapping in arid regions. *EGU General Assembly 2021*, EGU21-6982. ([abstract](https://meetingorganizer.copernicus.org/EGU21/EGU21-6982.html))
- Diebold, F. X., & Mariano, R. S. (1995). Comparing predictive accuracy. *Journal of Business & Economic Statistics, 13*(3), 253–263.
- Funk, C., Peterson, P., Landsfeld, M., et al. (2015). The climate hazards infrared precipitation with stations—a new environmental record for monitoring extremes. *Scientific Data, 2*, 150066. https://doi.org/10.1038/sdata.2015.66
- Gal, Y., & Ghahramani, Z. (2016). Dropout as a Bayesian approximation: Representing model uncertainty in deep learning. *Proceedings of the 33rd International Conference on Machine Learning (ICML)*, PMLR 48, 1050–1059.
- Gao, H., Birkett, C., & Lettenmaier, D. P. (2012). Global monitoring of large reservoir storage from satellite remote sensing. *Water Resources Research, 48*, W09504. <https://doi.org/10.1029/2012WR012063>
- Garg, S., Dasgupta, A., Motagh, M., Martinis, S., & Selvakumaran, S. (2024). Unlocking the full potential of Sentinel-1 for flood detection in arid regions. *Remote Sensing of Environment, 315*, 114417. <https://doi.org/10.1016/j.rse.2024.114417>
- Gibbs, I., & Candès, E. (2021). Adaptive conformal inference under distribution shift. *Advances in Neural Information Processing Systems, 34*.
- Gorelick, N., Hancher, M., Dixon, M., Ilyushchenko, S., Thau, D., & Moore, R. (2017). Google Earth Engine: Planetary-scale geospatial analysis for everyone. *Remote Sensing of Environment, 202*, 18–27. https://doi.org/10.1016/j.rse.2017.06.031
- Gupta, H. V., Kling, H., Yilmaz, K. K., & Martinez, G. F. (2009). Decomposition of the mean squared error and NSE performance criteria: Implications for improving hydrological modelling. *Journal of Hydrology, 377*(1–2), 80–91. https://doi.org/10.1016/j.jhydrol.2009.08.003
- Harvey, D., Leybourne, S., & Newbold, P. (1997). Testing the equality of prediction mean squared errors. *International Journal of Forecasting, 13*(2), 281–291.
- He, K., Zhang, X., Ren, S., & Sun, J. (2016). Deep residual learning for image recognition. *Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 770–778.
- Iakubovskii, P. (2019). *Segmentation Models Pytorch*. GitHub repository. https://github.com/qubvel/segmentation\_models.pytorch
- Kadam, A. S., & Dhakne, A. R. (2025). Transfer learning based CNN and LSTM models for water body identification and water level forecasting. *International Journal of Environmental Sciences*. \[verify year\] [https://doi.org/10.64252/3vfave66](https://theaspd.com/index.php/ijes/article/view/7919)
- Konapala, G., Kumar, S. V., & Ahmad, S. K. (2021). Exploring Sentinel-1 and Sentinel-2 diversity for flood inundation mapping using deep learning. *ISPRS Journal of Photogrammetry and Remote Sensing, 180*. https://doi.org/10.1016/j.isprsjprs.2021.08.016 ([record](https://ntrs.nasa.gov/citations/20220000062))
- Koyya, S., Pradhan, A., Swami, S., & Ari, S. (2025). Attention-driven U-Net for improved water body segmentation from satellite imagery. *17th IEEE International Conference on Computational Intelligence and Communication Networks (CICN)*, NIT Goa. ([record](https://dspace.nitrkl.ac.in/dspace/handle/2080/5552))
- Mahto, S. S., Fatichi, S., & Galelli, S. (2025). A 1985–2023 time series dataset of absolute reservoir storage in Mainland Southeast Asia (MSEA-Res). *Earth System Science Data, 17*, 2693–2712. <https://doi.org/10.5194/essd-17-2693-2025>
- Martinis, S., Plank, S., & Ćwik, K. (2018). The use of Sentinel-1 time-series data to improve flood monitoring in arid areas. *Remote Sensing, 10*(4), 583. <https://doi.org/10.3390/rs10040583>
- McFeeters, S. K. (1996). The use of the Normalized Difference Water Index (NDWI) in the delineation of open water features. *International Journal of Remote Sensing, 17*(7), 1425–1432.
- MFGF-UNet: A multi-modality fusion and gated multi-filter U-Net for water area segmentation in remote sensing. \[verify authors, year, journal\] ([record](https://researcher.ibm.com/publications/a-multi-modality-fusion-and-gated-multi-filter-u-net-for-water-area-segmentation-in-remote-sensing))
- Mobsite, S., Hostache, R., Berti-Équille, L., Roux, E., & Guérin, J. (2025). Not every day is a sunny day: Synthetic cloud injection for deep land cover segmentation robustness evaluation across data sources. *arXiv:2510.03006*. \[verify year; preprint\] ([arXiv](https://arxiv.org/abs/2510.03006))
- Muñoz-Sabater, J., Dutra, E., Agustí-Panareda, A., et al. (2021). ERA5-Land: A state-of-the-art global reanalysis dataset for land applications. *Earth System Science Data, 13*, 4349–4383. https://doi.org/10.5194/essd-13-4349-2021
- Nash, J. E., & Sutcliffe, J. V. (1970). River flow forecasting through conceptual models part I — A discussion of principles. *Journal of Hydrology, 10*(3), 282–290.
- NDR U-Net: Segmentation of water bodies in remote sensing satellite images using nested dense residual U-Net. \[verify authors, year, journal\] ([record](https://iieta.org/node/17346))
- Otsu, N. (1979). A threshold selection method from gray-level histograms. *IEEE Transactions on Systems, Man, and Cybernetics, 9*(1), 62–66.
- Pekel, J.-F., Cottam, A., Gorelick, N., & Belward, A. S. (2016). High-resolution mapping of global surface water and its long-term changes. *Nature, 540*, 418–422. https://doi.org/10.1038/nature20584 \[verify DOI\] ([record](https://research.google/pubs/high-resolution-mapping-of-global-surface-water-and-its-long-term-changes/))
- Progressive attention-enhanced EfficientNet–UNet for robust water-body mapping from satellite imagery. (2026). *Sensors, 26*(3), 963. \[verify authors\] [https://doi.org/10.3390/s26030963](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12899645/)
- Retief, H., Vigneswaran, K., Ghosh, S., Garcia Andarcia, M., & Dickens, C. (2025). Satellite-surface-area machine-learning models for reservoir storage estimation: Regime-sensitive evaluation and operational deployment at Loskop Dam, South Africa. *arXiv:2502.19989*. \[preprint\] ([arXiv](https://arxiv.org/abs/2502.19989v3))
- Ronneberger, O., Fischer, P., & Brox, T. (2015). U-Net: Convolutional networks for biomedical image segmentation. *Medical Image Computing and Computer-Assisted Intervention (MICCAI 2015)*, LNCS 9351, 234–241.
- Uday, G., Purse, B. V., Kelley, D. I., Vanak, A., Samrat, A., Chaudhary, A., Rahman, M., & Gerard, F. F. (2025). Radar versus optical: The impact of cloud cover when mapping seasonal surface water for health applications in monsoon-affected India. *PLoS ONE, 20*(1), e0314033. [https://doi.org/10.1371/journal.pone.0314033](https://nora.nerc.ac.uk/id/eprint/538849/)
- Vovk, V., Gammerman, A., & Shafer, G. (2005). *Algorithmic Learning in a Random World*. Springer.
- Xu, H. (2006). Modification of normalised difference water index (NDWI) to enhance open water features in remotely sensed imagery. *International Journal of Remote Sensing, 27*(14), 3025–3033.
- Yin, Z., Wu, P., Li, X., Hao, Z., Ma, X., Fan, R., Liu, C., & Ling, F. (2024). Super-resolution water body mapping with a feature collaborative CNN model by fusing Sentinel-1 and Sentinel-2 images. *International Journal of Applied Earth Observation and Geoinformation, 134*, 104176. \[verify DOI\] ([record](https://doaj.org/article/1d1a00695e2e49a19d503f780a9739f3))
- Chennai Water Management dataset. Kaggle. Daily reservoir levels and rainfall for Chennai's four reservoirs, 2004–2020. \[verify uploader and URL\]
